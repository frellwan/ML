#!/usr/bin/env python
import sys
from pyspark import SparkConf, SparkContext

conf = SparkConf().setMaster("local").setAppName("OrphanPages")
conf.set("spark.driver.bindAddress", "127.0.0.1")
sc = SparkContext(conf = conf)

def splitPageID(line):
    line = line.strip()
    pageID, links = line.split(':')
        
    return str(pageID)

def splitLinks(line):
    line = line.strip()
    pageID, links = line.split(':')
    
    #Get links into a list
    linksList = links.split()
    
    return linksList

lines = sc.textFile(sys.argv[1], 1) 

pageIDs = lines.map(lambda line: splitPageID(line))
linkList = lines.flatMap(lambda line: splitLinks(line))

orphans = pageIDs.subtract(linkList).collect()

orphans.sort()

output = open(sys.argv[2], "w")

for page in orphans:
    line = (page + '\n')
    output.write(line)

sc.stop()